import json 


lines = [
    '{"title": "Book X" "year": 2019, "price_eur": 8}',
    '{"title": "Book Y", "year": 2020, "price_eur": 12}'
]

books = []

for line in lines: 
    try: 
        