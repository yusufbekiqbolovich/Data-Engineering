import json
import re

lines = [
    '{"title": "Book C" "year": 2022 "price_eur": 15}'
]

books = []

for line in lines:
    try:
        book = json.loads(line)
    except json.JSONDecodeError:
        # Regex: insert comma between "key" and "next_key"
        fixed_line = re.sub(r'"\s+"', '", "', line)
        book = json.loads(fixed_line)

    # Convert numeric types
    book['year'] = int(book['year'])
    book['price_eur'] = float(book['price_eur'])

    books.append(book)

print(books)
