import json

# Sample lines from the file
lines = [
    '{"title": "Book A" "year": 2020, "price_eur": 10}',
    '{"title": "Book B", "year": 2021, "price_eur": 20}'
]

books = []

for line in lines:
    try:
        # Try to parse directly
        book = json.loads(line)
    except json.JSONDecodeError:
        # Fix common error: missing comma between title and year
        fixed_line = line.replace('" "', '", "')
        book = json.loads(fixed_line)
    
    books.append(book)

print(books)

rows = []

for book in books:
    rows.append({
        "title": book.get("title"),
        "year": int(book.get("year")),
        "price_usd": round(float(book.get("price_eur")) * 1.2, 2)  # EUR -> USD
    })

print(rows)

